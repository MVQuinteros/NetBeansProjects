/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quinteros.repaso;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * Clase Vectores
 * 
 * Aca se agrupan todos los ejercicios de vectores (arrays de una dimension)
 * que fui haciendo. Cada metodo es un ejercicio.
 * El metodo main NO esta aca, esta en Menu.
 * 
 * Regla basica de un vector:
 *   - es una lista de elementos, todos del mismo tipo
 *   - se accede con un indice: vector[0], vector[1], vector[2]...
 *   - se recorre con UN solo bucle (for).
 *   - longitud = vector.length
 *
 * @author Usuario
 */
public class Vectores {
    private final Scanner teclado = new Scanner(System.in);

    /**
     * Metodo de apoyo: pide un entero por teclado sin repetir codigo.
     */
    public int traerInt(String mjs){
        System.out.print(mjs);
        int entero = teclado.nextInt();
        teclado.nextLine();
        return entero;
    }

    /**
     * Metodo de apoyo: pide un texto por teclado.
     */
    public String traerString(String mjs){
        System.out.print(mjs);
        String ingreso = teclado.nextLine();
        return ingreso;
    }

    /**
     * Metodo de apoyo: pide un float (con coma o punto) por teclado.
     */
    public float traerFloat(String mjs){
        System.out.print(mjs);
        String ingreso = teclado.nextLine().replace(",", ".");
        float flo = Float.parseFloat(ingreso);
        return flo;
    }

    /**
     * ============ EJERCICIO 1 ============
     * Consigna: crear un vector donde almacenar 5 sueldos.
     * Ordenar el vector de sueldos de MAYOR a MENOR.
     *
     * Este es el famoso "ordenamiento burbuja":
     *   - dos bucles (uno adentro del otro)
     *   - si el de la izquierda es menor que el de la derecha, se intercambian
     *   - se necesita una variable AUXILIAR para poder intercambiar
     */
    public void ej1OrdenarSueldosMayorMenor(){
        int cant = traerInt("Ingrese cuantos numeros quiere cargar: ");
        float[] sueldos = new float[cant];
        for(int x = 0 ; x < cant ; x = x + 1){
            sueldos[x] = traerFloat("Ingrese elemento " + (x+1) + " : " );
        }

        // ciclamos (cantidad-1) veces porque comparamos de a pares
        float aux;
        for(int y = 0 ; y < (cant-1) ; y = y + 1){
            for(int x = 0 ; x < (cant-1) ; x = x + 1){
                // si el de arriba (izquierda) es menor que el de abajo (derecha)
                // los invertimos para que quede de mayor a menor
                if(sueldos[x] < sueldos[x+1]){
                    aux = sueldos[x];
                    sueldos[x] = sueldos[x+1];
                    sueldos[x+1] = aux;
                }
            }
        }
        System.out.print("El vector ordenado de mayor a menor es: ");
        for(int x = 0 ; x < cant ; x = x + 1){
            System.out.println(" - " + sueldos[x]);
        }
    }

    /**
     * ============ EJERCICIO 2 ============
     * Consigna: cargar un vector de n elementos de tipo entero.
     * Ordenarlo de MENOR a MAYOR y despues de MAYOR a MENOR.
     * Imprimir el vector desordenado y el ordenado.
     *
     * Es lo mismo que el ejercicio 1 pero para ambos sentidos,
     * y mostraba el vector recien cargado antes de ordenar.
     */
    public void ej2OrdenarMenorMayorYMayorMenor(){
        int cantidad = traerInt("Ingresar la longitud del Vector: ");
        int[] vector = new int[cantidad];
        for(int x = 0 ; x < cantidad ; x = x + 1){
            vector[x] = traerInt("Ingrese el elemento numero " + (x+1) + ": ");
        }
        imprimirVector(vector, cantidad, "El Vector recien ingresado es: ");

        // ordenar de menor a mayor
        int aux;
        for(int x = 0 ; x < (cantidad-1) ; x = x + 1){
            for(int y = 0 ; y < (cantidad-1) ; y = y + 1){
                if(vector[y] > vector[y+1]){
                    aux = vector[y];
                    vector[y] = vector[y+1];
                    vector[y+1] = aux;
                }
            }
        }
        imprimirVector(vector, cantidad, "El vector ordenado de menor a mayor es: ");

        // ordenar de mayor a menor (invertimos la condicion del if)
        for(int x = 0 ; x < (cantidad-1) ; x = x + 1){
            for(int y = 0 ; y < (cantidad-1) ; y = y + 1){
                if(vector[y] < vector[y+1]){
                    aux = vector[y];
                    vector[y] = vector[y+1];
                    vector[y+1] = aux;
                }
            }
        }
        imprimirVector(vector, cantidad, "El vector ordenado de mayor a menor es: ");
    }

    /**
     * ============ EJERCICIO 3 ============
     * Consigna: cargar los nombres de 5 alumnos y sus notas.
     * Ordenar las notas de mayor a menor.
     * Imprimir las notas y los nombres de los alumnos JUNTOS.
     *
     * Esto son VECTORES PARALELOS: dos vectores que se ordenan juntos,
     * cuando muevo una nota tambien muevo el nombre que va con ella.
     */
    public void ej3NotasAlumnosParalelos(){
        final int cantidad = 5;
        int[] notas = new int[cantidad];
        String[] nombres = new String[cantidad];

        System.out.println("Carga de Alumnos y notas");
        for(int x = 0 ; x < cantidad ; x = x + 1){
            nombres[x] = traerString("Ingrese el nombre del estudiante: ");
            notas[x] = traerInt("Ingrese la nota de " + nombres[x] + " : ");
        }
        imprimirAlumnos(nombres, notas, cantidad, "Vectores recien cargados: ");

        // ordenar notas de mayor a menor, arrastrando los nombres
        int auxNotas;
        String auxNombres;
        for(int x = 0 ; x < (cantidad-1) ; x = x + 1){
            for(int y = 0 ; y < (cantidad-1) ; y = y + 1){
                if(notas[y] < notas[y+1]){
                    // guardo ambos en auxiliares antes de pisarlos
                    auxNotas = notas[y];
                    auxNombres = nombres[y];
                    notas[y] = notas[y+1];
                    nombres[y] = nombres[y+1];
                    notas[y+1] = auxNotas;
                    nombres[y+1] = auxNombres;
                }
            }
        }
        imprimirAlumnos(nombres, notas, cantidad, "Vectores Ordenados: ");
    }

    /**
     * ============ EJERCICIO 4 ============
     * Consigna: cargar 5 paises y su cantidad de habitantes.
     * Ordenar los paises ALFABETICAMENTE (manteniendo cada pais junto a sus habitantes).
     *
     * Para ordenar textos se usa compareTo:
     *   - paises[y].compareTo(paises[y+1]) > 0  ->  el de la izquierda va DESPUES (hay que moverlo)
     *   - da 0 si son iguales, negativo si va antes
     */
    public void ej4PaisesAlfabeticamente(){
        final int cantidad = 5;
        String[] paises = new String[cantidad];
        float[] habitantes = new float[cantidad];

        System.out.println("Carga de Paises y Habitantes ");
        for(int x = 0 ; x < cantidad ; x = x + 1){
            paises[x] = traerString("Ingrese el nombre del pais: ");
            habitantes[x] = traerFloat("Ingrese la cantidad de habitantes de " + paises[x] + " : ");
        }
        imprimirPaises(paises, habitantes, cantidad, "Vector recien cargado: ");

        // ordenar paises alfabeticamente (arrastrando habitantes)
        String auxPaises;
        float auxHabitantes;
        for(int x = 0 ; x < (cantidad-1) ; x = x + 1){
            for(int y = 0 ; y < (cantidad-1) ; y = y + 1){
                if(paises[y].compareTo(paises[y+1]) > 0){
                    auxPaises = paises[y];
                    paises[y] = paises[y+1];
                    paises[y+1] = auxPaises;

                    auxHabitantes = habitantes[y];
                    habitantes[y] = habitantes[y+1];
                    habitantes[y+1] = auxHabitantes;
                }
            }
        }
        imprimirPaises(paises, habitantes, cantidad, "Vector ordenado alfabeticamente: ");
    }

    /**
     * ============ EJERCICIO 5 ============
     * Consigna: cargar un vector de n elementos y
     * buscar el MENOR numero, contando cuantas veces se repite.
     *
     * Tecnica del "menor":
     *   - suponemos que el menor es el primero (vector[0])
     *   - recorremos el vector y si aparece uno mas chico, actualizamos
     */
    public void ej5MenorYRepetidos(){
        int cant = traerInt("Ingrese cuantos numeros quiere cargar: ");
        float[] numeros = new float[cant];
        for(int x = 0 ; x < cant ; x = x + 1){
            System.out.print("Ingrese elemento " + x + " : " );
            numeros[x] = teclado.nextFloat();
        }

        // suponemos que el primero es el menor
        float numMenor = numeros[0];
        // contamos cuantas veces aparece el menor (empieza en 1 porque el primero ya lo es)
        int repetidos = 1;

        // buscar menor
        for(int x = 1 ; x < cant ; x = x + 1){
            if(numeros[x] < numMenor){
                numMenor = numeros[x];
                repetidos = 1;
            }else{
                if(numeros[x] == numMenor){
                    repetidos = repetidos + 1;
                }
            }
        }

        System.out.println("El numero mas chico de los ingresados es: " + numMenor);
        if(repetidos > 1){
            System.out.println("Se repite " + repetidos + " veces");
        }else{
            System.out.println("No se repite");
        }
    }

    // ==================================================================
    // METODO DE PRACTICA (no es un ejercicio exacto, es una HERRAMIENTA)
    // ==================================================================

    /**
     * Herramienta de practica: llenar un vector con numeros al AZAR
     * usando Random para no tener que cargar los datos a mano.
     *
     * random.nextInt(valorMaximo) devuelve un entero entre 0 y valorMaximo-1.
     * Si le sumo 1 -> numeros entre 1 y valorMaximo.
     */
    public void practicaVectorConRandom(){
        Random random = new Random();
        int cant = traerInt("Ingrese cuantos numeros quiere cargar: ");
        int valorMaximo = traerInt("Ingrese el valor maximo que puede tomar cada numero: ");
        int[] vector = new int[cant];
        for(int x = 0 ; x < cant ; x = x + 1){
            vector[x] = random.nextInt(valorMaximo) + 1;
        }
        imprimirVector(vector, cant, "Vector cargado al azar: ");
    }

    // METODOS DE APOYO: los uso para imprimir sin repetir codigo.

    public void imprimirVector(int[] vector, int cant, String mjs){
        System.out.println(mjs);
        for(int x = 0 ; x < cant ; x = x + 1){
            System.out.println(" - " + vector[x]);
        }
    }

    public void imprimirAlumnos(String[] nombres, int[] notas, int cant, String mjs){
        System.out.println(mjs);
        for(int x = 0 ; x < cant ; x = x + 1){
            System.out.println(nombres[x] + " : " + notas[x]);
        }
    }

    public void imprimirPaises(String[] paises, float[] habitantes, int cant, String mjs){
        System.out.println(mjs);
        for(int x = 0 ; x < cant ; x = x + 1){
            System.out.println(paises[x] + " = " + habitantes[x]);
        }
    }
}
