/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quinteros.repaso;

import java.util.Scanner;

/**
 *
 * Clase Menu
 * 
 * Este es el programa PRINCIPAL. Aca esta el metodo main.
 * 
 * La idea es tener TODO junto en un solo proyecto para poder estudiar:
 *   - la clase Vectores  -> todos los ejercicios de vectores
 *   - la clase Matrices  -> todos los ejercicios de matrices
 *   - esta clase Menu    -> elige cual ejercicio probar
 * 
 * Asi no tenemos que abrir un proyecto distinto por cada ejercicio.
 * 
 * Si queres probar un ejercicio especifico, elegi su numero en el menu.
 * Con 0 se sale del programa.
 *
 * @author Usuario
 */
public class Menu {
    private final Scanner teclado = new Scanner(System.in);
    private final Vectores vectores = new Vectores();
    private final Matrices matrices = new Matrices();

    public void mostrarMenu(){
        System.out.println("==============================================");
        System.out.println("   REPASO PARCIAL - VECTORES Y MATRICES");
        System.out.println("==============================================");
        System.out.println();
        System.out.println("VECTORES:");
        System.out.println("  1. Ordenar sueldos de mayor a menor");
        System.out.println("  2. Ordenar vector de menor a mayor y viceversa");
        System.out.println("  3. Notas y nombres de alumnos (vectores paralelos)");
        System.out.println("  4. Paises ordenados alfabeticamente");
        System.out.println("  5. Menor numero y cuantas veces se repite");
        System.out.println();
        System.out.println("MATRICES:");
        System.out.println("  6. Cargar y mostrar matriz 4x4");
        System.out.println("  7. Matriz con filas y columnas distintas (3x5)");
        System.out.println("  8. Mostrar la diagonal principal de una matriz");
        System.out.println("  9. Mostrar la ultima fila de una matriz");
        System.out.println(" 10. Mayor elemento y su posicion");
        System.out.println(" 11. Intercambiar la primer fila con la segunda");
        System.out.println(" 12. Mostrar los cuatro vertices");
        System.out.println(" 13. Recorrer matriz con .length");
        System.out.println();
        System.out.println("HERRAMIENTAS (de practica, no son ejercicios del parcial):");
        System.out.println(" 14. Llenar un vector al azar con Random");
        System.out.println(" 15. Llenar una matriz al azar con Random");
        System.out.println();
        System.out.println("  0. Salir");
        System.out.println();
    }

    public void ejecutar(){
        int opcion;
        do{
            mostrarMenu();
            System.out.print("Ingrese una opcion: ");
            opcion = teclado.nextInt();
            System.out.println();

            switch(opcion){
                // VECTORES
                case 1 -> vectores.ej1OrdenarSueldosMayorMenor();
                case 2 -> vectores.ej2OrdenarMenorMayorYMayorMenor();
                case 3 -> vectores.ej3NotasAlumnosParalelos();
                case 4 -> vectores.ej4PaisesAlfabeticamente();
                case 5 -> vectores.ej5MenorYRepetidos();
                // MATRICES
                case 6 -> matrices.ej1CargarMostrar();
                case 7 -> matrices.ej1bMatrizFilasColumnasDistintas();
                case 8 -> matrices.ej2MostrarDiagonal();
                case 9 -> matrices.ej3UltimaFila();
                case 10 -> matrices.ej4MayorElementoYPosicion();
                case 11 -> matrices.ej5IntercambiarFilas();
                case 12 -> matrices.ej6Vertices();
                case 13 -> matrices.ej7RecorrerConLength();
                // HERRAMIENTAS
                case 14 -> vectores.practicaVectorConRandom();
                case 15 -> matrices.practicaMatrizConRandom();
                // SALIR
                case 0 -> System.out.println("Chau! Suerte en el parcial ;)");
                default -> System.out.println("Opcion invalida. Elegi un numero del menu.");
            }
            System.out.println();
        }while(opcion != 0);
    }

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.ejecutar();
    }
}
